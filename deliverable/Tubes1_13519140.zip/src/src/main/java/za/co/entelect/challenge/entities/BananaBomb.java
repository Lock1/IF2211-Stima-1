package za.co.entelect.challenge.entities;

import com.google.gson.annotations.SerializedName;

public class BananaBomb {
    @SerializedName("count")
    public int count;
}
