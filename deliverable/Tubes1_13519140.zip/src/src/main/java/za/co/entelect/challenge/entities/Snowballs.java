package za.co.entelect.challenge.entities;

import com.google.gson.annotations.SerializedName;

public class Snowballs {
    @SerializedName("count")
    public int count;
}
